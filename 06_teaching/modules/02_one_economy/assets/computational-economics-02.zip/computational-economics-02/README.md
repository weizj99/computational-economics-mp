# Computational Economics — Unit 02: Inside one economy

The code and data for unit 02. Each file keeps its path in the course
repository, https://github.com/weizj99/computational-economics-mp, so the
commands in the course work here unchanged. Run them from this folder.

## Set up

You need Python 3.10 or later. Install NumPy and SciPy:

    python -m pip install -r requirements-cpu.txt

## Run

Solve the economy that lesson 02.3 traces and compare it with the page, in
about ten seconds:

    python lessons/02_one_economy/parameters_to_moments.py

The script prints phi, the operating firms, the three moments, the employment
totals, one firm of Market 1 and Market 1's contributions, each next to the
value saved for the page in 06_teaching/modules/02_one_economy. All 25 lines
should match. The three moments should equal the saved values; on another
computer they can differ in the last digit. --case sigma_3 solves the next
point on the sigma path, and --firm 3 shows another firm of Market 1.

To solve an economy with parameters of your choice, use the course's CPU
solver. With 200 markets it takes about a second:

    python run.py cpu --markets 200 --output outputs/example_cpu

Each run saves the three moments, the firm arrays and the solver diagnostics.
`python run.py cpu --help` lists the settings you can change, and
`python run.py test` runs the tests.

## Where to read

- Entry and exit
  07_python/qmp/equilibrium.py: _solve_period, solve_economy
- Cournot and equilibrium
  07_python/qmp/equilibrium.py: solve_shares, _prices, _solve_output, _solve_period
- Parameters to moments
  lessons/02_one_economy/parameters_to_moments.py: page_draws, calculate, main
  07_python/qmp/draws.py: generate_draws, build_productivity
  07_python/qmp/__init__.py: simulate
  07_python/qmp/equilibrium.py: solve_economy
  07_python/qmp/moments.py: compute_moments

## Licence and credit

The code is under the Apache License 2.0 (LICENSE, NOTICE) and the text under
CC BY 4.0 (LICENSE-CONTENT). RIGHTS.md says how to credit the course, and
data/README.md lists the sources of the data.
