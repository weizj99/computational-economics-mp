# Computational Economics — Unit 05: Untargeted moment

The code and data for unit 05. Each file keeps its path in the course
repository, https://github.com/weizj99/computational-economics-mp, so the
commands in the course work here unchanged. Run them from this folder.

## Set up

You need Python 3.10 or later. Install NumPy and SciPy:

    python -m pip install -r requirements-cpu.txt

## Run

The figure also needs Matplotlib:

    python -m pip install matplotlib

Solve the 44 annual economies again at the unit 03 estimates and split the
change in the markup. This takes about 18 core-minutes, or about 5 minutes
with four workers:

    python lessons/05_untargeted/decompose_markup.py --workers 4 --figure

The results go to outputs/untargeted. The unit 03 estimates are in
06_teaching/modules/03_estimation/assets/annual_parameters.csv. Check what the
script prints: the moments differ from unit 03's saved values by 0, the three
parts add up to within 1e-15, and 27 of the 43 pairs of years have new draws.

## Where to read

- Untargeted moment
  lessons/05_untargeted/decompose_markup.py: solve_year, decompose, levels
  07_python/qmp/untargeted.py: markup_decomposition, centred_moving_average

## Licence and credit

The code is under the Apache License 2.0 (LICENSE, NOTICE) and the text under
CC BY 4.0 (LICENSE-CONTENT). RIGHTS.md says how to credit the course, and
data/README.md lists the sources of the data.
