# Computational Economics — Unit 03: Estimating the economy

The code and data for unit 03. Each file keeps its path in the course
repository, https://github.com/weizj99/computational-economics-mp, so the
commands in the course work here unchanged. Run them from this folder.

## Set up

You need Python 3.10 or later. Install NumPy and SciPy:

    python -m pip install -r requirements-cpu.txt

## Run

Search one year as the full estimation does. The script maps the first 64 of
the course's 512 Sobol points into the search box for 2000, solves each
economy, and prints the lowest loss with its three contributions. It then
compares every economy with the saved candidate table that the website uses,
website/modules/03_estimation/assets/search_results.csv:

    python lessons/03_estimation/search_year.py --year 2000 --points 64

On the machine used for the course, one economy for 2000 took about 4.5
seconds on one core, so 64 points take about five minutes; --workers 4 solves
four economies at a time. Any year from 1980 to 2023 works, and --points 512
runs the whole year. The candidates go to outputs/search_2000/candidates.csv.

The full search solves 512 candidate economies for each year from 1980 to 2023,
22,528 in all: about 60 core-hours, most of them for the 1980s. This runs eight
shards side by side, which takes about eight hours with eight cores:

    python lessons/03_estimation/full_search.py --workers 8

It fixes the candidates and the inputs, solves the shards, and then chooses the
best candidate for each year (outputs/annual_run/annual_estimates.csv). Each
solved candidate is saved at once, so a stopped run carries on when you start it
again. Add --limit 2 for a quick test; an unfinished run marks its choice as
provisional. The three steps are also commands of their own, run from the
model folder: `python -m qmp.estimation prepare`, `solve` and `select`.

## Where to read

- From parameter candidates to a selected economy
  lessons/03_estimation/search_year.py: solve_candidate, compare, main
  model/qmp/estimation.py: read_inputs, standard_sobol_points, make_points, prepare, solve, rank_records, select
  lessons/03_estimation/full_search.py: main

## Licence and credit

The code is under the Apache License 2.0 (LICENSE, NOTICE) and the text under
CC BY 4.0 (LICENSE-CONTENT). RIGHTS.md says how to credit the course, and
data/README.md lists the sources of the data.
