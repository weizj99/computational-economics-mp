# Computational Economics — Unit 04: Parallel computing and acceleration

The code and data for unit 04. Each file keeps its path in the course
repository, https://github.com/weizj99/computational-economics-mp, so the
commands in the course work here unchanged. Run them from this folder.

## Set up

You need Python 3.10 or later. Install NumPy and SciPy:

    python -m pip install -r requirements-cpu.txt

## Run

The CPU code needs only NumPy and SciPy. The GPU code also needs an NVIDIA GPU
and PyTorch with CUDA (and threadpoolctl for the GPU checks); docs/GPU.md
describes its entry points.

Time the same 256 economies with 1, 2 and 4 worker processes. Each worker
count solves all 256; one worker took about 19 minutes on the machine used for
the recorded runs. Add --cases 16 for a quick version:

    python lessons/04_parallel/scaling.py --workers 1 2 4

Time the market-share solver in one call and in one call per market, for 5
to 80 firms per market (lesson 02, about 30 seconds):

    python lessons/04_parallel/loop_vs_vectorized.py

Solve the output equations of unit 02's baseline economy with Newton's method
and bisection, and compare the roots with the model's (the extra exercise):

    python lessons/04_parallel/output_root.py

Check the GPU code against the CPU solver: the single-economy reference on 17
economies, the batched engine on 8, and the market-share block:

    python lessons/04_parallel/check_gpu.py

Solve one fixed economy on the GPU, or on both and compare:

    python lessons/04_parallel/gpu_economy.py --case candidate_000 --compare

Write two small example points, then solve them with the batched engine:

    python run.py example-inputs outputs/gpu_inputs
    python run.py gpu outputs/gpu_inputs/points.csv outputs/gpu_run --contract outputs/gpu_inputs/contract.json

The first run for a given number of potential firms compiles the GPU kernels,
so it is slower than later runs.

## Where to read

- Parallel workers
  lessons/04_parallel/scaling.py: start_worker, solve_case, trial
  model/qmp/estimation.py: solve, select
  lessons/03_estimation/full_search.py: main
- Vectorization
  model/qmp/equilibrium.py: solve_shares, solve_shares.update
  lessons/04_parallel/loop_vs_vectorized.py: by_market, main
- GPU batches
  gpu/batched/run_points_current.py: groups, solve_rows
  gpu/batched/qmp_torch_current.py: solve_batch_current
- Kernel fusion (optional)
  gpu/batched/qmp_torch_current.py: _share_step
  gpu/batched/qmp_torch_share_fused.py: share_step_fused, _share_step_kernel
- Resident loops (optional)
  gpu/batched/qmp_torch_precision.py: solve_shares_mixed
  gpu/batched/qmp_torch_share_resident.py: solve_shares_resident_mixed, resident_updates, _resident_kernel, resident_backend
  gpu/batched/qmp_torch_current.py: _share_residual
- Profiling
  gpu/batched/qmp_torch_current.py: solve_batch_current, _period, solve_shares_current
- Mixed precision (optional)
  gpu/batched/qmp_torch_precision.py: _fp32_predict, solve_shares_mixed, precision_backend
  gpu/batched/qmp_torch_current.py: _share_residual
- Fair comparison
  gpu/batched/run_points_current.py: solve_rows
  model/qmp/estimation.py: diagnostic_quality, validate_record
- Output equation (extra exercise)
  lessons/04_parallel/output_root.py: Dual, newton, bisection, main
  model/qmp/equilibrium.py: _solve_output

## Licence and credit

The code is under the Apache License 2.0 (LICENSE, NOTICE) and the text under
CC BY 4.0 (LICENSE-CONTENT). RIGHTS.md says how to credit the course, and
data/README.md lists the sources of the data.
